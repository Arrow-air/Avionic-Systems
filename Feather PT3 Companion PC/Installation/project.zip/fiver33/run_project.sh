#!/bin/bash

# Pls Navigate to your project directory
cd /path/to/your/project

# Run your Python project
python3 main.py
